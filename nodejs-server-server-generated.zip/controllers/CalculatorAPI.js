'use strict';

var utils = require('../utils/writer.js');
var CalculatorAPI = require('../service/CalculatorAPIService');

module.exports.apiCalculatePOST = function apiCalculatePOST (req, res, next, body, operation) {
  CalculatorAPI.apiCalculatePOST(body, operation)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
