'use strict';


/**
 *
 * body CalculatorRequest 
 * operation String Specify the operation (add, subtract, multiply, divide)
 * no response value expected for this operation
 **/
exports.apiCalculatePOST = function(body,operation) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}

